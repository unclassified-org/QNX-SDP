// JavaScript Document

var currentView = 1;
var nextAction = 1;
var actionInProgress = false;
var distance = 0;
var action1interval;
var action2interval;

function prev()
{
	if (currentView > 1)
	{
		var fromView = currentView;
		transformViews(fromView, "translate(" +  (--currentView - 1) * -800 + "px)");
	}
}

function next()
{
	if (currentView < 3)
	{
		var fromView = currentView;		
		transformViews(fromView, "translate(" + -800 * currentView++ + "px)");
	}
}

function transformViews(fromView, transform)
{
	if(fromView == 2)
	{
		switch (nextAction - 1)
		{
			case 1:
				clearAction1();
				break;
				
			case 3:
				clearAction3();
				break;
		}
	}
		
	nextAction = 1;
	stopAnimations();

	var view1 = document.getElementById("view1");
	var view2 = document.getElementById("view2");
	var view3 = document.getElementById("view3");

	switch (currentView)
	{
		case 1: 
			view1.style.webkitTransform = transform;
		case 2: 
			view2.style.webkitTransform = transform;
		case 3: 
			view3.style.webkitTransform = transform;
	}
}

function action ()
{
	//stopAnimations();
	
	switch(nextAction) 
	{
		case 1:
		   clearActions();
			action1();
			nextAction = 2;
			break;
			
		case 2:
			clearActions();
			action2();
			nextAction = 3;
			break;
			
		case 3:
		   clearActions();
			action3();
			nextAction = 4;
			break;
			
		case 4:
			clearActions();
			action4();
			nextAction = 1;
			break;			
	}
}

function clearActions()
{
	image1.style.display = "";
	image1.className = "";
	image2.style.display= "";
	image2.className = "";
	vector1.style.display= "none";
	vector2.style.display= "none";
   text1.style.display = "";
   text1.className = "";
}

function action1()
{	
	document.getElementById("sequence_num").innerHTML = "Sequence 1";
	image1.className += "img1action";
	image2.className += "img2action";
	text1.className += "txt1action";
}  

function action2()
{
	document.getElementById("sequence_num").innerHTML = "Sequence 2";
	image1.className = "img1action2";
	image2.className = "img2action2";
	text1.className = "txt1action2";
}

function action3()
{
	document.getElementById("sequence_num").innerHTML = "Sequence 3";
	image1.className = "img1action3";
	image2.className = "img2action3";
	text1.className = "txt1action3";
}

function action4()
{
	document.getElementById("sequence_num").innerHTML = "Sequence 4";
   vector1.style.display = "block";
   vector2.style.display = "block";
	image1.style.display = "none";
	image2.style.display = "none";
	vector1.className = "vec1action4";
	vector2.className = "vec2action4";
	text1.className = "txt1action4";
}

function stopAnimations()
{
	image1.style.display= "";
	image1.className = "";
	image2.style.display= "";
	image2.className = "";
	//vectors.className = " vectors";
	//footnote.className = " view_footnote";
}