// JavaScript Document

var currentViewLeft = 1;
var currentViewRight = 1;
var nextAction = 1;
var actionInProgress = false;
var distance = 0;
var action1interval;
var action2interval;

function left()
{
	if (currentViewLeft <= 3)
	{
		var fromView = currentViewLeft;
		if(currentViewLeft == 3)
			currentViewLeft = 0
		transformViewsLeft(fromView, "translateY(" +  (currentViewLeft) * -412 + "px)");
		currentViewLeft++
	}
}

function right()
{
	if (currentViewRight <= 3)
	{
		var fromView = currentViewRight;
		if(currentViewRight == 3)
			currentViewRight = 0
		transformViewsRight(fromView, "translateY(" +  (currentViewRight) * 412 + "px)");
		currentViewRight++
	}
}

function transformViewsLeft(fromView, transform)
{
	var viewsLeft = document.getElementById("viewsLeft");
	viewsLeft.style.webkitTransform = transform
}

function transformViewsRight(fromView, transform)
{
	var viewsLeft = document.getElementById("viewsRight");
	viewsLeft.style.webkitTransform = transform
}