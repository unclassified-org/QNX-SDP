// JavaScript Document

var POPUP_STYLE_NAME = 'popup_style';
var POPUP_BODY_STYLE_NAME = 'popup_body_style';
var POPUP_CLOSEBT_STYLE_NAME = 'popup_closebt_style';
var POPUP_TOPBT_STYLE_NAME = 'popup_topbt_style';
var POPUP_TITLE_NAME = 'popup_title_style';
var POPUP_MESSAGE_NAME = 'popup_message_style';

function BluePopup(title_text,message_text,closeCallback) {
	this._currentListFragment;
	
	var fragment = document.createDocumentFragment();

	var popupContainer = fragment.appendChild(document.createElement('div'));
	popupContainer.className = POPUP_STYLE_NAME;

	var btnTop = document.createElement('div');
	btnTop.className = POPUP_TOPBT_STYLE_NAME;
	popupContainer.appendChild(btnTop);

	var popupBody = document.createElement('div');
	popupBody.className = POPUP_BODY_STYLE_NAME;
	popupContainer.appendChild(popupBody);

	var btnClose = document.createElement('div');
	btnClose.className = POPUP_CLOSEBT_STYLE_NAME;
	btnClose.addEventListener('click',closeCallback,false)	
	popupContainer.appendChild(btnClose);
	
	this.title = document.createElement('div');
	this.title.className = POPUP_TITLE_NAME;
	popupContainer.appendChild(this.title);	
	
	this.message  = document.createElement('div');
	this.message.className = POPUP_MESSAGE_NAME;
	popupContainer.appendChild(this.message);
	
	this.title.innerHTML = title_text;
	this.message.innerHTML = message_text;
	
	this._currentListFragment = fragment;
}

BluePopup.prototype.setText = function(title,message) {
	title.innerHTML = title;
	message.innerHTML = message;
}