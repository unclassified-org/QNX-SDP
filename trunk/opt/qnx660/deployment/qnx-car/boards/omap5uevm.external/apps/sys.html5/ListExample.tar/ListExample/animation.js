// JavaScript Document

var currentView = 1;
var nextAction = 1;
var actionInProgress = false;
var distance = 0;
var action1interval;
var action2interval;

function prev()
{
	document.getElementById("popupdd").style.display = "none";
	if (currentView > 1)
	{
		var fromView = currentView;
		transformViews(fromView, "translate(" +  (--currentView - 1) * -800 + "px)");
	}
}

function next()
{
	document.getElementById("popupdd").style.display = "none";
	if (currentView < 5)
	{
		var fromView = currentView;		
		transformViews(fromView, "translate(" + -800 * currentView++ + "px)");
	}
}

function transformViews(fromView, transform)
{
	
	var view1 = document.getElementById("view1");
	var view2 = document.getElementById("view2");
	var view3 = document.getElementById("view3");
	var view4 = document.getElementById("view4");
	var view5 = document.getElementById("view5");

	switch (currentView)
	{
		case 1: 
			view1.style.webkitTransform = transform;
		case 2: 
			view2.style.webkitTransform = transform;
		case 3: 
			view3.style.webkitTransform = transform;
		case 4: 
			view4.style.webkitTransform = transform;
		case 5: 
			view5.style.webkitTransform = transform;
	}
}