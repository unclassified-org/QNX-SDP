// JavaScript Document

var currentView = 1;
var nextAction = 1;
var actionInProgress = false;
var distance = 0;
var action1interval;
var action2interval;

function prev()
{
	if (currentView > 1)
	{
		var fromView = currentView;
		transformViews(fromView, "translate(" +  (--currentView - 1) * -800 + "px)");
	}
}

function next()
{
	if (currentView < 3)
	{
		var fromView = currentView;		
		transformViews(fromView, "translate(" + -800 * currentView++ + "px)");
	}
}

function transformViews(fromView, transform)
{
	if(fromView == 2)
	{
		switch (nextAction - 1)
		{
			case 1:
				clearAction1();
				break;
				
			case 3:
				clearAction3();
				break;
		}
	}
		
	nextAction = 1;
	stopAnimations();

	var view1 = document.getElementById("view1");
	var view2 = document.getElementById("view2");
	var view3 = document.getElementById("view3");

	switch (currentView)
	{
		case 1: 
			view1.style.webkitTransform = transform;
		case 2: 
			view2.style.webkitTransform = transform;
		case 3: 
			view3.style.webkitTransform = transform;
	}
}

function action ()
{
	if (currentView == 2)
	{
		stopAnimations();
		
		switch(nextAction) 
		{
			case 1:
				action1();
				nextAction = 2;
				break;
				
			case 2:
				clearAction1();
				action2();
				nextAction = 3;
				break;
				
			case 3:
				action3();
				nextAction = 4;
				break;
				
			case 4:
				clearAction3();
				action4();
				nextAction = 1;
				break;			
		}
		
	}
}

function action1()
{	
	images.className += " action1img";
	vectors.className += " action1vec";
	footnote.className += " action1txt";

	action1interval = 0;
	setTimeout(action1p2, 1000);
}

function action1p2()
{
	if (nextAction-1 != 1) return;

	footnote.innerHTML = "Distance: " + ++distance/10 + " miles";
	if (action1interval == 0)
	{
		action1interval = setInterval(action1p2, 250);
	}
}

function clearAction1()
{
	if (nextAction-1 != 1) return;

	clearInterval(action1interval);
	distance = 0;
	footnote.innerHTML = "Distance: 0.0 miles";
}

function action2()
{
	images.className += " action2img";	
	vectors.className += " action2vec";	
}

function action3()
{
	footnote.style.display = "none"
	images.style.display= "none";
	document.getElementById("view2_veclbl").style.display = "";
	
	vectors.style.left = "200px";
	vectors.className += " action3vec";
}

function clearAction3()
{
	footnote.style.display = "";
	images.style.display= "";
	document.getElementById("view2_veclbl").style.display = "none";
	vectors.style.left = "400px";
}

function action4()
{
	images.className += " action4";	
	vectors.className += " action4";	
	footnote.className += " action4";	
}

function stopAnimations()
{
	images.style.display= "";
	images.className = "images";
	vectors.className = " vectors";
	footnote.className = " view_footnote";
}