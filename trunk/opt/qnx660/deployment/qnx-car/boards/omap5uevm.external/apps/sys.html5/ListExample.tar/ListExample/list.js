// JavaScript Document

const LIST_STYLE_NAME = "list_body";
const CELL_STYLE_NAME = "cell_body";


/** Default item rendederer 
Loosk like single label list item
*/
function DefaultRenderer() {
	this._data = {};
	this.itemDiv;
	this._index;
}

DefaultRenderer.prototype.dataProvider = function(data,index) {

	itemDiv = document.createElement('div');
	itemDiv.className = CELL_STYLE_NAME;
	
	if(data) {
		
		_data = data;
		_index = index;
		
		var label = itemDiv.appendChild(document.createElement('div'));
		label.className = "cell_content";
		label.innerHTML = index + " " +  data.label;
		
		if(index%2 == 0)
			itemDiv.className = CELL_STYLE_NAME + " odd";
		else
			itemDiv.className = CELL_STYLE_NAME + " even";
			
		this._currentItemFragment = itemDiv;
	}
}

/** CheckBoxItemRenderer 
Loosk like checkbox and label item
*/

function CheckBoxItemRenderer() {
	this._data = {};
	this.itemDiv;
	this._index;
}

CheckBoxItemRenderer.prototype.dataProvider = function(data,index) {

	itemDiv = document.createElement('div');
	
	if(data) {
		
		_data = data;
		_index = index;
		
		var cb = document.createElement('input');
		cb.type = 'checkbox';
		cb.name = 'checkbox' + index;
		cb.value = data.label;
		cb.className = "cell_content";
		
		itemDiv.appendChild(cb);
		
		var label = itemDiv.appendChild(document.createElement('div'));
		label.className = "label";
		label.innerHTML = data.label;
		
		itemDiv.appendChild(label);
		
		if(index%2 == 0)
			itemDiv.className = "CheckBoxItemRenderer " + CELL_STYLE_NAME + " odd";
		else
			itemDiv.className = "CheckBoxItemRenderer " + CELL_STYLE_NAME + " even";
			
		this._currentItemFragment = itemDiv;
	}
}


/** List */
/**
List is base class for all other underlying lists.
Support simple Swipe up/down to navigate the List.
Uses native scrolling and positioning.

List allow user to change renderer for single items.
Rendeder pretty much define UI and data structure for the single list item.
List is abstract anough to now know how single items looks like.
*/

function List() {
		/** Represent current dataset, private */
		this._data = {};
		/** already preprocessed markup reflecting up to date state of the list, private and readonly */
		this._currentMarkup = "";
		//this._currentListFragment;,
		this.width = 300;
		this.height = 300;
		this.cellElements = new Array();
		this.listDiv;
		this.itemRenderer = new DefaultRenderer();
		this.currentIndex = 0;
		this.currentScrollElement = 0;
		this.currentScrollElementBottom = 0;
		this.firstScroll = true;
}

List.prototype.dataProvider = function(data) {

	this.cellElements = new Array();

	var fragment = document.createDocumentFragment();
	this.listDiv = fragment.appendChild(document.createElement('div'));
	this.listDiv.className = LIST_STYLE_NAME;
	
	if(data) {
		
		this._data = data;
		
		var itemContent;
	
		for (i = 0; i < data.length; i++) {
			var _item = data[i];
			
			if(this.itemRenderer) {
				this.itemRenderer.dataProvider(_item,i);
				itemContent = this.itemRenderer._currentItemFragment;
			}
			
			this.listDiv.appendChild(itemContent);

			this.cellElements.push(itemDiv);
		}

		this._currentListFragment = this.listDiv;
	}
}

List.prototype.setCellRenderer = function(renderer) {
	
}

List.prototype.setSelected = function(value) {
	
}

List.prototype.getSelected = function() {
	return null;	
}

/** ButtonList */
/**
ButtonList uses 2 buttons at the top and at the bottom of the list to scroll up and down.
Swipe not enabled
*/

var BUTTON_LIST_STYLE_NAME = "button_list"
var BTN_TOP_CLASS_NAME = "btn_top"
var BTN_BOTTOM_CLASS_NAME = "btn_botom"

ButtonList.prototype = new List();        // Here's where the inheritance occurs 
ButtonList.prototype.constructor=ButtonList;
function ButtonList(name){ 
	this.btnTop;
	this.btnBottom;
	this.currentIndex = 0;
	this.prevIndex = 0
	this._data = {};
	this.cellElements;
}

ButtonList.prototype.dataProvider = function(data) {

	cellElements = new Array();

	var fragment = document.createDocumentFragment();

	var butonListContainer = fragment.appendChild(document.createElement('div'));
	butonListContainer.className = BUTTON_LIST_STYLE_NAME;	

	btnTop = document.createElement('div');
	btnTop.className = BTN_TOP_CLASS_NAME;
	btnTop.addEventListener('click',buttonDownClick,false)	
	butonListContainer.appendChild(btnTop);

	this.listDiv = butonListContainer.appendChild(document.createElement('div'));
	this.listDiv.className = LIST_STYLE_NAME;
	butonListContainer.appendChild(this.listDiv);
	
	if(data) {
		
		this._data = data;
		
		var itemContent;
	
		for (i = 0; i < data.length; i++) {
			var _item = data[i];
		
			if(this.itemRenderer) {
				this.itemRenderer.dataProvider(_item,i);
				itemContent = this.itemRenderer._currentItemFragment;
			}
			
			this.listDiv.appendChild(itemContent);

			this.cellElements.push(itemDiv);
		}	
		
		btnBottom = document.createElement('div');
		btnBottom.addEventListener('click',buttonUpClick,false)	
		btnBottom.className = BTN_BOTTOM_CLASS_NAME;
		butonListContainer.appendChild(btnBottom);
		
		this._currentListFragment = butonListContainer;	
	}
	
	var ref = this;
	
	setSelected();
	
	function buttonUpClick() {
		if(ref.currentIndex <= ref._data.length) {
			ref.prevIndex = ref.currentIndex;
			ref.currentIndex++;
			setSelected();
		}
	}

	function buttonDownClick() {
		if(ref.currentIndex > 0) {
			ref.prevIndex = ref.currentIndex;
			ref.currentIndex--;
			setSelected();
		}
	}
	
	function setSelected(){
		var cellElement = ref.cellElements[ref.currentIndex];
		var cellElementPrev = ref.cellElements[ref.prevIndex];
		//cellElement.scrollIntoView();
		
		ScrollToElement(cellElement,ref.listDiv)
		
		cellElement.className += " selected";
		cellElementPrev.className = cellElementPrev.className.replace(" selected","");	
	}
}

/** ThumbList */
/**
ThumbList uses button to control scrolling. Button resemble scrollbar bUP and DOWN buttons and also scroll thumb to display relative position of the selected item in the lsit
*/

var THUMB_LIST_STYLE_NAME = "thumb_list"
var THUMBBTN_TOP_CLASS_NAME = "thumb_btn_top"
var THUMBBTN_BOTTOM_CLASS_NAME = "thumb_btn_botom"
var THUMB_TRACK_TOP_CLASS_NAME = "thumb_track"
var SCROLL_THUMB_TOP_CLASS_NAME = "thumb_scroll";

var SCROLL_Y_FROM = 108;
var SCROLL_Y_TO = 260;

ThumbList.prototype = new List();        // Here's where the inheritance occurs 
ThumbList.prototype.constructor=ThumbList;
function ThumbList(name){ 
	this.btnTop;
	this.btnBottom;
	this.currentIndex = 0;
	this.prevIndex = 0
	this._data = {};
	this.cellElements;
}

ThumbList.prototype.dataProvider = function(data) {

	cellElements = new Array();

	var fragment = document.createDocumentFragment();

	var thumbListContainer = fragment.appendChild(document.createElement('div'));
	thumbListContainer.className = THUMB_LIST_STYLE_NAME;	

	var track = document.createElement('div');
	track.className = THUMB_TRACK_TOP_CLASS_NAME;
	thumbListContainer.appendChild(track);
	
	var scrollThumb = document.createElement('div');
	scrollThumb.className = SCROLL_THUMB_TOP_CLASS_NAME;
	scrollThumb.id = "scrollThumb";
	thumbListContainer.appendChild(scrollThumb);

	btnTop = document.createElement('div');
	btnTop.className = THUMBBTN_TOP_CLASS_NAME;
	btnTop.addEventListener('click',buttonDownClick,false)	
	thumbListContainer.appendChild(btnTop);

	listDiv = thumbListContainer.appendChild(document.createElement('div'));
	listDiv.className = LIST_STYLE_NAME;
	thumbListContainer.appendChild(listDiv);
	
	if(data) {
		
		this._data = data;
		
		var itemContent;
	
		for (i = 0; i < data.length; i++) {
			var _item = data[i];
			
			if(this.itemRenderer) {
				this.itemRenderer.dataProvider(_item,i);
				itemContent = this.itemRenderer._currentItemFragment;
			}
			
			listDiv.appendChild(itemContent);

			this.cellElements.push(itemDiv);
		}	
		
		btnBottom = document.createElement('div');
		btnBottom.addEventListener('click',buttonUpClick,false)	
		btnBottom.className = THUMBBTN_BOTTOM_CLASS_NAME;
		thumbListContainer.appendChild(btnBottom);
		
		this._currentListFragment = thumbListContainer;
	}
	
	var ref = this;
	
	function buttonUpClick() {
		if(ref.currentIndex < ref._data.length - 1) {
			ref.prevIndex = ref.currentIndex;
			ref.currentIndex++;
			setSelected();
		}
	}

	function buttonDownClick() {
		if(ref.currentIndex > 0) {
			ref.prevIndex = ref.currentIndex;
			ref.currentIndex--;
			setSelected();
		}
	}
	
	function setSelected(){
		var cellElement = ref.cellElements[ref.currentIndex];

		if(!cellElement)
			return;

		var cellElementPrev = ref.cellElements[ref.prevIndex];
		cellElement.scrollIntoView();
		cellElement.className += " selected";
		cellElementPrev.className = cellElementPrev.className.replace(" selected","");	
		
		updateScrollThumb();
	}

	function updateScrollThumb(){
		var delta = SCROLL_Y_TO - SCROLL_Y_FROM;
		var pxPerItem = delta / ref._data.length;
		var offset = SCROLL_Y_FROM + (pxPerItem * ref.currentIndex);
		scrollThumb.style.top = offset;
	}
}

/** RoundList */
/**
RoundList wraps around when user reached one of the ends of the lists.
User sees tails of the list when he scroll up, and beginning of the list of he scroll down beyoud the boundaries of original dataset
*/
var DYNAMIC_LIST_STYLE_NAME = "round_list"

RoundList.prototype = new List();        // Here's where the inheritance occurs 
RoundList.prototype.constructor=RoundList;
function RoundList(name){ 
	this.btnTop;
	this.btnBottom;
	this.currentIndex = 0;
	this.prevIndex = 0
	this._data = {};
	this.cellElements;
}

RoundList.prototype.dataProvider = function(data) {

	this.cellElements = new Array();

	var fragment = document.createDocumentFragment();
	this.listDiv = fragment.appendChild(document.createElement('div'));
	this.listDiv.className = LIST_STYLE_NAME;
	
	//to intercept user scrolling
	this.listDiv.addEventListener('scroll',onScroll,false)
	
	if(data) {
		
		this._data = data;
		
		var itemContent;
	
		for (i = 0; i < data.length; i++) {
			var _item = data[i];
			
			if(this.itemRenderer) {
				this.itemRenderer.dataProvider(_item,i);
				itemContent = this.itemRenderer._currentItemFragment;
			}
			
			this.listDiv.appendChild(itemContent);

			this.cellElements.push(itemDiv);
		}

		this._currentListFragment = this.listDiv;
		this.currentScrollElementBottom = data.length - 1;
	}
	
	var ref = this;
	
	function onScroll(e){
		var listHeightCSS = this.clientHeight;
		var numChildren = this.children.length;
		//console.log("listHeightCSS:",listHeightCSS)
		//console.log("Scrolling")
		//console.log(this.scrollTop)
		
		// get default height of the cell
		var cellHeight = ref.cellElements[0].clientHeight;
		
		// scrolling down
		if(this.scrollTop >= numChildren * 50 - listHeightCSS - 51) {
			//console.log("Need to start adding at the bottom")
			//var cellElements
			//var __nodes = new Array();
			__nodes = ref.listDiv.childNodes;
			var _first = __nodes[0]
			//var child = listDiv.removeChild(_first)
			ref.listDiv.appendChild(ref.cellElements[ref.currentScrollElement].cloneNode(true))
			listDiv.scrollTop = (listDiv.scrollTop - 1);
			
			//console.log(this.scrollTop)
			//console.log(e)
			
			ref.currentScrollElement++;
			if(ref.currentScrollElement == ref._data.length)
				ref.currentScrollElement = 0;
		}
		
		// scrolling up
		if(this.scrollTop <= 1 || ref.firstScroll) {
			
			//console.log("Need to start adding at the top")
			
			var realChildren = this.children;
			
			var currentNode = ref.cellElements[ref.currentScrollElementBottom];

			// insert before whatewer is first element
			ref.listDiv.insertBefore(currentNode.cloneNode(true),realChildren[0]);

			if(!ref.firstScroll)
				ref.listDiv.scrollTop = (ref.listDiv.scrollTop + 50);
			ref.firstScroll = false;
			
			//console.log(this.scrollTop)
			//console.log(e)
			
			ref.currentScrollElementBottom--;
			if(ref.currentScrollElementBottom < 0)
				ref.currentScrollElementBottom = ref._data.length-1;
		}
	}
}

/** DynamicList */
/**

Dynamic list uses AJAX style calls to server to add new data to the list dynamically
New items loaded when user reaching end of the list,
Items can be loaded in batches controlled by developer:
requests parameters are:
action - define what exactly to load, user feined, shoul match action defined in serverside script
length - length of piece to be added
offset - offset withing data block, can be used to load data starting from specific point, useful when working with database backend

*/
var DYNAMIC_LIST_STYLE_NAME = "dynamic_list"

DynamicList.prototype = new List();        // Here's where the inheritance occurs 
DynamicList.prototype.constructor=DynamicList;
function DynamicList(name){ 
	this.btnTop;
	this.btnBottom;
	this.currentIndex = 0;
	this.prevIndex = 0
	this._data = {};
	this.cellElements;
}

/** Creates initial set of data, also intialises list and creates all required UI structures*/
DynamicList.prototype.dataProvider = function(data) {

	this.cellElements = new Array();

	var fragment = document.createDocumentFragment();
	this.listDiv = fragment.appendChild(document.createElement('div'));
	this.listDiv.className = LIST_STYLE_NAME;
	
	//to intercept user scrolling
	this.listDiv.addEventListener('scroll',onScroll,false)
	
	if(data) {
		
		this._data  = data;
		
		var itemContent;
	
		for (i = 0; i < data.length; i++) {
			var _item = data[i];
			
			if(this.itemRenderer) {
				this.itemRenderer.dataProvider(_item,i);
				itemContent = this.itemRenderer._currentItemFragment;
			}
			
			this.listDiv.appendChild(itemContent);

			this.cellElements.push(itemDiv);
		}

		this._currentListFragment = this.listDiv;
	}
	
	var ref = this;
	
	function onScroll(e){
		var listHeightCSS = this.clientHeight;
		var numChildren = this.children.length;
		//console.log("listHeightCSS:",listHeightCSS)
		//console.log("Scrolling")
		//console.log(this.scrollTop)
		
		// get default height of the cell
		var cellHeight = ref.cellElements[0].clientHeight;
		
		// scrolling down
		if(this.scrollTop >= numChildren * 50 - listHeightCSS - 51) {
			//console.log("Need to start adding at the bottom")
			PassAjaxResponseToFunction("do.php?action=load&length=10",ref.appendData,ref)
		}
	}

/** Adds new data to the main dataset */	
DynamicList.prototype.appendData = function(data) {
	
	var evalData = eval(data);
	
	if(evalData) {			
		// append new data
		this._data.join(evalData);
		
		var itemContent;
	
		for (i = 0; i < evalData.length; i++) {
			var _item = evalData[i];
			
			if(this.itemRenderer) {
				this.itemRenderer.dataProvider(_item,i);
				itemContent = this.itemRenderer._currentItemFragment;
			}
			
			this.listDiv.appendChild(itemContent);

			this.cellElements.push(itemDiv);
		}
	}
}
}

/** simple alternative to scrollToView, still slow */
function ScrollToElement(theElement,parent){
 parent.scrollTop = theElement.offsetTop;
 console.log(theElement.offsetTop)
}
