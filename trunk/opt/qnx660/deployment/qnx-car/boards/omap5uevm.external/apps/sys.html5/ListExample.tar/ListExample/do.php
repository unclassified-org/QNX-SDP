<?php

 error_reporting(E_ALL);
 ini_set("display_errors", 1); 

# Using REQUEST_URI
$url = "http://" . $_SERVER['HTTP_HOST']  . $_SERVER['REQUEST_URI'];

# $offset = $_GET['offset'];
$length = $_GET['length'];
$action = $_GET['action'];

$result = "";

if($action == "load") {
	$result = "{data:[";
    for ($p = 0; $p < $length; $p++) {
        $result .= "{label:'".getUniqueCode()."'},";
    }
	$result .= "]}";
	echo $result;
}

?>

<?php
    //generate random string
	function genRandomString() {
	    $length = 10;
	    $characters = '0123456789abcdefghijklmnopqrstuvwxyz';
	    $string = "";    
	    for ($p = 0; $p < $length; $p++) {
	       $string .= $characters[mt_rand(0, strlen($characters))];
	    }

	    return $string;
	}
	
    function getUniqueCode($length = "")
    {
    $code = md5(uniqid(rand(), true));
    if ($length != "") return substr($code, 0, $length);
    else return $code;
    }
?>