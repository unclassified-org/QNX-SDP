///////////////////////////////////////////////////////////////////
// JavaScript wrapper for JNEXT PPS plugin
///////////////////////////////////////////////////////////////////

JNEXT.PPS = (function()
{
    var self = this;
    var ppsObj = {};
    var m_strObjId;
    
    self.open = function( strPPSPath, mode ) {
        var strVal = JNEXT.invoke( self.m_strObjId, "Open", strPPSPath + " " + mode );
        
        //alert('PPS.open ' + strVal ); 
        
        var arParams = strVal.split( " " );
        return ( arParams[ 0 ] == "Ok" );
    };
    
    self.read = function() {
    	// Read a line from the file that was previously opened
        var strVal = JNEXT.invoke( self.m_strObjId, "Read" );
        var arParams = strVal.split( " " );
        if ( arParams[ 0 ] != "Ok" ) {
            return null;
        }
		  var json = strVal.substr( arParams[0].length + 1 );
        //alert('ppsObj ' + json);
        self.ppsObj = JSON.parse(json);
        
        return;
    };
      
    self.write = function(obj) {
		var jstr = JSON.stringify(obj);
		var strVal = JNEXT.invoke(self.m_strObjId, "Write", jstr);
        var arParams = strVal.split( " " );
        return ( arParams[ 0 ] == "Ok" );
    }
    
    self.close = function() {
        strRes = JNEXT.invoke( self.m_strObjId, "Close" );
        strRes = JNEXT.invoke( self.m_strObjId, "Dispose" );
        JNEXT.unregisterEvents( self );
    };
    
    self.getId = function() {
        return self.m_strObjId;
    };
    
    self.onEvent = function( strData ) {
        var arData = strData.split( " " );
        var strEventDesc = arData[ 0 ];
        switch ( strEventDesc )
        {
            case "Error":
            {
                self.onError();
                break;
            }
            
            case "OnChange":
            {
				   var jsonData = strData.substr(strEventDesc.length + 1);
				   var data = JSON.parse(jsonData);
				   //alert('onChange w/data ' + data);
				   self.read(); // update pps object 
               self.onChange(data);
               break;
            }
        }
    };
    
    self.onError = function()
    {
        alert( "onError" );
    };
    
    self.onChange = function(data)
    {
        for (var key in data) {
           var obj = data[key];
           for (var prop in obj) {
              if( prop == "slider" ){
                 $('#slider').val(self.ppsObj[prop]).slider("refresh");
                 //alert( $('#slider').val() ); 
              }
           }
        }
    };
    
    self.init = function() {
        if ( !JNEXT.require( "pps" ) ) {
	    	alert("no pps");
            return false;
        }
        
        self.m_strObjId = JNEXT.createObject( "pps.PPS" );
        if ( self.m_strObjId == "" )  {
            alert( "error initializing pps" );
            return false;
        }
        
        JNEXT.registerEvents( self );
    };
    
    //self.m_strObjId = "";
    //self.init();
    
    return self;
    
}());

///////////////////////////////////////////////////////////////////
