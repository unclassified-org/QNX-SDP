
var qnxcar;
if( !qnxcar ) {
    qnxcar = {};
}

qnxcar.auth = (function()
{
    var auth = {},
    
    ppsInitAttempted,
    ppsReadTokenAttempted,
    
    cachedTokenValid,
    cachedToken;

    jnextCommand = function( request )
    {
        var waitedForJNEXT,
            response;
        
        while( typeof objJSExt !== 'function' ) {
            // YUCK -- but the JNEXT extension takes a bit of time to initialize and we need
            // this to be synchronous -- luckily, providing the <embed> tag is in the HTML
            // when the page is loaded, this loop does not ever seem to run.  It's just here so
            // we can recover if we had to add the JNEXT extension dynamically in ppsInit() below.
            waitedForJNEXT = true; 
        }
        
        if( waitedForJNEXT ) {
            alert( 'waited for JNEXT' );
        }

        // alert( 'objJSExt = ' + objJSExt );
        // alert( 'JNEXT command: request = "' + request + '"' );
        
        response = objJSExt.sendCmd( request );

        // A successful response starts with 'Ok '
        if( response.length < 2 || response[ 0 ] !== 'O' || response[ 1 ] !== 'k' ) {
            // alert( 'JNEXT error: request = "' + request + '", response = "' + response + '"' );
            return null;
        }

        // alert( 'JNEXT success: request = "' + request + '", response = "' + response + '"' );
        return response;
    };

    ppsInit = function()
    {
        var jnextDIV;
        
        if( ppsInitAttempted ) {
            return;
        }
        ppsInitAttempted = true;
  
        if( !$('#objJSExt' ) ) {
            alert( 'dynamically adding JNEXT' );
            //jnextDIV = rim.HTML.create( 'div', null, null, '<embed id="objJSExt" type="application/jnext-scriptable-plugin" width="0" height="0">' );
            //document.body.appendChild( jnextDIV );
        }

        //if( !jnextCommand( 'userAgent ' + navigator.userAgent ) || 
        //    !jnextCommand( 'Require pps' ) ) {
        //    alert('jnextCommand failed');
        //    return;
        //}
        
        alert('we did it!');
        return;
    };    

    ppsReadToken = function()
    {
        var response,
            ppsObjectID,
            ppsObject,
            jsonData;
        
        ppsReadTokenAttempted = true;

        ppsInit();
    };

    auth.getToken = function() 
    {
        cachedToken = ppsReadToken();
        cachedTokenValid = true;
        return cachedToken;
    };
    
}());


