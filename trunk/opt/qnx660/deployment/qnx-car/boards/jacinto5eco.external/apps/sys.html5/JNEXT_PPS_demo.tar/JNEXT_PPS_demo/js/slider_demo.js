window.onload = function()
{
	JNEXT.require("pps");
	JNEXT.PPS.m_strObjId = JNEXT.createObject("pps.PPS");
	//alert('ObjId ' + JNEXT.PPS.m_strObjId);   
	JNEXT.registerEvents(JNEXT.PPS);
	JNEXT.PPS.open("/pps/system/sapphire/status","2"); // O_RDWR
	JNEXT.PPS.read();
	
	$('#slider').val(JNEXT.PPS.ppsObj.slider).slider("refresh");
};

$(document).bind("pagecreate", function() {
	
	$('.ui-slider').live('touchend', function(){
		JNEXT.PPS.write( {"slider":$(this).siblings('input').val()} );
	});

});
