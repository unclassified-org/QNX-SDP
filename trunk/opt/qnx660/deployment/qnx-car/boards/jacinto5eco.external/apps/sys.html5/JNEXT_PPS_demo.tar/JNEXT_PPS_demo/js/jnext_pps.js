var JNEXT;

var sapphire;
if( !sapphire ) {
    sapphire = {};
}

sapphire.jnext_pps = (function()
{
   var m_bFirstRequire = true;
   var jnext_pps = {},
   
   ppsInitAttempted,
   
   jnextCommand;


   jnextCommand = function( request )
   {
       var waitedForJNEXT,
           response;
       
       while( typeof objJSExt !== 'function' ) {
           // YUCK -- but the JNEXT extension takes a bit of time to initialize and we need
           // this to be synchronous -- luckily, providing the <embed> tag is in the HTML
           // when the page is loaded, this loop does not ever seem to run.  It's just here so
           // we can recover if we had to add the JNEXT extension dynamically in ppsInit() below.
           waitedForJNEXT = true; 
       }
       
       if( waitedForJNEXT ) {
           alert( 'waited for JNEXT' );
       }

       response = objJSExt.sendCmd( request );

       // A successful response starts with 'Ok '
       if( response.length < 2 || response[ 0 ] !== 'O' || response[ 1 ] !== 'k' ) {
           alert( 'JNEXT error: request = "' + request + '", response = "' + response + '"' );
           return null;
       }

       // alert( 'JNEXT success: request = "' + request + '", response = "' + response + '"' );
       return response;
   };

   jnext_pps.init = function()
   {
       var jnextDIV;
       
       if( ppsInitAttempted ) {
           return false;
       }
       ppsInitAttempted = true;
 
       if( !$('objJSExt' ) ) {
           alert( 'dynamically adding JNEXT' );
           jnextDIV = rim.HTML.create( 'div', null, null, '<embed id="objJSExt" type="application/jnext-scriptable-plugin" width="0" height="0">' );
           document.body.appendChild( jnextDIV );
       }
       
       if( !jnextCommand( 'userAgent ' + navigator.userAgent ) || 
           !jnextCommand( 'Require pps' ) ) {
           return false;
       }

       return true;
   };    

   jnext_pps.createObject = function( strObjName )
   {
       // Create an instance of a native object
       var strCmd;
       var strVal;
       var arParams;
       strVal = jnextCommand( "CreateObject " + strObjName );

       arParams = strVal.split( " " );
       if ( arParams[ 0 ] != "Ok" )
       {
           alert("CreateObject: " + strVal );
           return "";
       }
       return arParams[ 1 ];
   }

   return jnext_pps;
    
}());
